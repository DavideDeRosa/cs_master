API_KEY = "c804c071bc1447589eb170658240511"
API_URL = "https://api.weatherapi.com/v1/"